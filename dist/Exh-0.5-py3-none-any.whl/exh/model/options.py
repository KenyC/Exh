# Whether automatic alternatives use subconstituents alternatives by default
sub = True

# Default size of the domain of quantification of quantifiers
dom_quant = 3 

# Whether display is in Latex by default
latex_display = True

